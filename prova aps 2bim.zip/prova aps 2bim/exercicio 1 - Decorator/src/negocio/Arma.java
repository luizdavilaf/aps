package negocio;

public abstract class Arma {
    protected String description;
    
    
    public String getDescription(){
        return this.description;
    }
    
    
    
    
}
