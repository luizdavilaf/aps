
package negocio;


public class Pistola extends Arma {
    
    public Pistola(){
        super();
        super.description = "Pistola";
    
    }

  
    
}
