package negocio;

public class Arduino {    
    
    
    public Arduino() {
    }   

    public void shutdown(){
        System.out.println("Sistema desligando");
    }

    public void hibernate(){
        System.out.println("Sistema hibernando");
    }

    public void restart(){
        System.out.println("Sistema reiniciando");
    }

    

    
    
}
