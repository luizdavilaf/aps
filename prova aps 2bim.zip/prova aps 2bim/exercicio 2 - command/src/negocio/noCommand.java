package negocio;

public class noCommand implements Command {

    @Override
    public void execute() {
    }

}
