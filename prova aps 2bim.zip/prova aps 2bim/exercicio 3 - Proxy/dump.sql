drop table pessoa CASCADE;

create table pessoa(
    id serial,    
    nome text not null,
    PRIMARY KEY (id)    
);











