
package apresentacao;

import negocio.PessoaProxy;


public class Main {

    
    public static void main(String[] args) {
        
    } 
}
