package negocio;


public class Extent {
    private double width;
    private double heigth;

    public Extent(int w, int h) {
        this.width = w;
        this.heigth = h;
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public double getHeigth() {
        return heigth;
    }

    public void setHeigth(double heigth) {
        this.heigth = heigth;
    }
    
    public String toString(){
        return "Width:"+this.width+" Heigth:"+this.heigth;
    }
    
}
