package negocio;

public interface Person {
    String getNome();
    String getId();
    
    
}
