
package negocio;


public class PessoaProxy implements Person {
    private String id;
    private Pessoa pessoa;
    

    public PessoaProxy(String id) {
        this.id = id;       

    }

    @Override
    public String getNome() {
        this.pessoa = new Pessoa(nome, id)
        return this.pessoa.nome;
    }


    @Override
    public String getId() {        
        return this.id;
    }

    
}
