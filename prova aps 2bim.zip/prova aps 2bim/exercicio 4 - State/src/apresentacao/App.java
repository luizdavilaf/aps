package apresentacao;
import negocio.Artigo;
import negocio.Usuario;

public class App {
    public static void main(String[] args) throws Exception {
        
         Artigo artigo1 = new Artigo();         
         Usuario adm = new Usuario(true);
         Usuario usr = new Usuario(false);
         artigo1.publicar(adm); //foi pra moderacao
         artigo1.publicar(adm); //foi publicado
         artigo1.publicar(adm); //nao acontece nada pois ja esta publicado
         Artigo artigo2 = new Artigo();
         artigo2.publicar(usr); //moderacao
         artigo2.publicar(usr); //fail pois nao é adm
         artigo2.publicar(usr); //fail pois nao é adm
         
         
        

        
        
    }
}
