package negocio;

public class Artigo {

    protected EstadoArtigo estado;
    protected boolean revisao;
    

    public Artigo() {
        this.estado = new Rascunho(); 
        this.revisao=true;       
    }

    @Override
    public String toString() {
        return estado.toString();
    }

    public EstadoArtigo getEstado() {
        return estado;
    }

    public void setEstado(EstadoArtigo estado) {
        this.estado = estado;
    }    

    public void publicar(Usuario usuario){        
        this.estado = this.estado.publicar(usuario);
    }

    public void reprovarRevisao(){
        this.revisao=false;
        this.estado= new Rascunho();
    }

    public void aprovarRevisao(){
        this.revisao=true;
    }

    public void expirarPublicacao(){
        this.estado= new Rascunho();
    }

    
    
}
