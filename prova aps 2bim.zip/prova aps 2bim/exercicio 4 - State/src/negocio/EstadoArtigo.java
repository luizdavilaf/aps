package negocio;

public interface EstadoArtigo {


    EstadoArtigo publicar(Usuario usuario);
    
    
}
