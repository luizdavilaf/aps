package negocio;

public class Moderacao implements EstadoArtigo{

    

    public Moderacao() {
        System.out.println("Artigo está na moderação");
    }

    @Override
    public EstadoArtigo publicar(Usuario usuario) {
        if(usuario.administrador==true){
            return new Publicado();
        }
        System.out.println("O artigo não pode ser publicado, pois o usuario nao é administrador");
        return this;
    }

}
