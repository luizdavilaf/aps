package negocio;

public class Publicado implements EstadoArtigo{

    public Publicado() {
        System.out.println("Artigo foi publicado");
    }

    @Override
    public EstadoArtigo publicar(Usuario usuario) {        
        return this;
    }
    
}
