package negocio;

public class Rascunho implements EstadoArtigo{    

    public Rascunho() {
        System.out.println("Artigo está no rascunho");
    }    

    @Override
    public EstadoArtigo publicar(Usuario usuario) {        
        return new Moderacao() ;
    }

    
    
}
