package negocio;

public class Usuario {
    protected boolean administrador;

    public Usuario(Boolean funcao) {
        this.administrador = funcao;
    }
    
}
