package negocio;

public interface CarroInterface {
    void manobrar(Empregado empregado);
    
}
