package negocio;

public interface Command{
    void execute();
    
}