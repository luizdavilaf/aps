package negocio;

public class Corrida {

    public void acelerar(){
        System.out.println("acelerando");
    }

    public void frear(){
        System.out.println("freando");        
    }
    
}
