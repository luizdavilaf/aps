package negocio;

public class Futebol {
    

    public void correr(){
        System.out.println("correndo");
    }

    public void chutar(){
        System.out.println("chutando a bola");        
    }
}
