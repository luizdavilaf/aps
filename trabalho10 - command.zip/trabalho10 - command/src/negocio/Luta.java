package negocio;

public class Luta {

    public void chutarAlto(){
        System.out.println("chutando alto");
    }

    public void socarAlto(){
        System.out.println("socando alto");        
    }
    
}
