package negocio.Armas;

public interface Arma {
    
    public int plusDano();

    public String getNome();

    public int getDano();
    
    
   
}
