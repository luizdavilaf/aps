package negocio;

public enum Direcao {
    CIMA, BAIXO, DIREITA, ESQUERDA, NAOMOVER;    
}
