package apresentacao;

import java.awt.Component;

import javax.swing.JOptionPane;

import negocio.Maquina;

public class App {
    public static void main(String[] args) throws Exception {
        /*
         * Maquina maquina1 = new Maquina();
         * maquina1.ejetaMoeda();
         * maquina1.abasteceMaquina(1);
         * maquina1.insereMoeda();
         * maquina1.acionaAlavanca();
         */

        Maquina maquina1 = new Maquina();
        //System.out.println((maquina1.getEstado().toString()).equals("Desligada"));

        Object[] options = { "Abastecer Máquina","Ejetar Moeda", "Acionar Alavanca", "Inserir Moeda",  "Desligar" };
        while ((maquina1.getEstado().toString()) != "Desligada")        {

            int n = JOptionPane.showOptionDialog(null,
                    "O que você deseja fazer?",
                    "Maquina de Goma",
                    JOptionPane.YES_NO_CANCEL_OPTION,
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    options,
                    options[4]);

            switch (n) {
                case 0:
                    maquina1.abasteceMaquina(
                            Integer.parseInt(JOptionPane.showInputDialog(null, "digite quantas gomas vai abastecer")));
                            JOptionPane.showMessageDialog(null, maquina1.getEstado().toString());
                    break;
                case 1:
                    maquina1.ejetaMoeda();
                    JOptionPane.showMessageDialog(null, maquina1.getEstado().toString());
                    break;
                case 2:
                    maquina1.acionaAlavanca();
                    JOptionPane.showMessageDialog(null, maquina1.getEstado().toString());
                    break;
                case 3:
                    maquina1.insereMoeda();
                    JOptionPane.showMessageDialog(null, maquina1.getEstado().toString());
                    break;
                default:
                    maquina1.desligar();
                    JOptionPane.showMessageDialog(null, maquina1.getEstado().toString());

            }
        }
    }
}
