package negocio;

public class Desligada implements EstadoMaquina{

    

    public Desligada() {
        System.out.println("Máquina desligada!!");
    }

    @Override
    public String toString() {
        return "Desligada";
    }

    @Override
    public EstadoMaquina ejetaMoeda() {
        
        return this;
    }

    @Override
    public EstadoMaquina acionaAlavanca() {
        return this;
    }

    @Override
    public EstadoMaquina entregaGoma() {
        return this;
    }

    @Override
    public EstadoMaquina insereMoeda() {
        return this;
    }

    @Override
    public EstadoMaquina abasteceMaquina(int gomas) {
        return this;
    }

    @Override
    public EstadoMaquina ligar() {        
        return new SemGoma();
    }

    @Override
    public EstadoMaquina desligar() {        
        return this;
    }
    
}
