package negocio;

import javax.swing.JOptionPane;

public class GomaVendida implements EstadoMaquina {

    public GomaVendida(){
        System.out.println("Goma Vendida!");
        JOptionPane.showMessageDialog(null, "Goma Vendida!");
        this.entregaGoma();         
    }

    @Override
    public String toString() {
        return "Goma Vendida";
    }

    @Override
    public EstadoMaquina ejetaMoeda() {
        return new SemMoeda();
    }

    @Override
    public EstadoMaquina acionaAlavanca() {       
        return new SemMoeda();
    }

    @Override
    public EstadoMaquina entregaGoma() {        
        return new SemMoeda();
    }

    @Override
    public EstadoMaquina insereMoeda() {        
        return new RecebeMoeda();
    }   

    @Override
    public EstadoMaquina abasteceMaquina(int gomas) {        
        return new SemMoeda();
    }

    @Override
    public EstadoMaquina ligar() {        
        return new SemMoeda();
    }

    @Override
    public EstadoMaquina desligar() {
        
        return new Desligada();
    }
    
}
