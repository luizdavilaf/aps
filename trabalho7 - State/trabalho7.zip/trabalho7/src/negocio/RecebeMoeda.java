package negocio;

import javax.swing.JOptionPane;

public class RecebeMoeda implements EstadoMaquina {

    public RecebeMoeda(){
        System.out.println("Moeda recebida, acione a alavanca!");
    }

    public RecebeMoeda(String string) {
    }

    @Override
    public EstadoMaquina ejetaMoeda() {
        JOptionPane.showMessageDialog(null,"Moedas ejetadas!");
        System.out.println("Moedas ejetadas!");
        return new SemMoeda();
    }

    @Override
    public EstadoMaquina acionaAlavanca() {        
        return new GomaVendida();
    }

    @Override
    public EstadoMaquina entregaGoma() {       
        return this;
    }

    @Override
    public EstadoMaquina insereMoeda() {        
        return this.ejetaMoeda() ;
    }

    @Override
    public EstadoMaquina abasteceMaquina(int entradagoma) {        
        return new SemMoeda();
    }

    @Override
    public EstadoMaquina ligar() {        
        return new SemMoeda();
    }
    
    @Override
    public EstadoMaquina desligar() {
        
        return new Desligada();
    }

    @Override
    public String toString() {
        return "Moeda Recebida";
    }
}
