package apresentacao;

import javax.swing.JOptionPane;

import negocio.*;

public class App {
    public static void main(String[] args) throws Exception {
        /*
         * Html site = new Head("Titulo da pagina");
         * site = new Header(site, new H1("Titulo de dentro da pagina"));
         * site = new Main(site);
         * site = new Body(site);
         * site = new Div(site, "tudo");
         * site = new H1(site, "titulo grande");
         * site = new H2(site, "titulozinho menor");
         * site = new Paragrafo(site, "este e o primeiro paragrafo");
         * site = new Paragrafo(site, "este e o segundo paragrafo");
         * site = new Link(site, "Google", "http://www.google.com");
         * site = new FechaDiv(site);
         * site = new FechaBodyMain(site);
         * site = new Footer(site, "este e o rodape");
         * site = new FechaSite(site);
         * 
         * // + tags site
         * site.build();//body,main,html
         */

        
        
        Html site = new Head(JOptionPane.showInputDialog(null,
                "Bem vindo a construçao de um site! \nDigite o titulo da sua pagina:"));
        site = new Header(site, new H1(JOptionPane.showInputDialog(null, "Digite o titulo do seu header")));
        site = new Main(site); 
        site = new Body(site);       
        boolean bodyAberto = true;        
        int divAberta = 0; 

        while (bodyAberto == true) {
            Object[] options = { "Inserir Div", "Inserir H1", "Inserir H2", "Inserir Parágrafo", "Inserir Link",
                    "Fechar Body", "Fechar Div", "Inserir Footer", "Concluir Site" };

            int n = JOptionPane.showOptionDialog(null,
                    "Qual tag você deseja inserir?",
                    "Html builder decorator",
                    JOptionPane.YES_NO_CANCEL_OPTION,
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    options,
                    options[8]);
            switch (n) {
                case 0: // inserir div
                    site = new Div(site, JOptionPane.showInputDialog(null, "digite a classe da div:"));
                    divAberta++;
                    break;
                case 1: // inserir h1
                    site = new H1(site, JOptionPane.showInputDialog(null, "digite o titulo do h1:"));
                    break;
                case 2:// inserir h2
                    site = new H2(site, JOptionPane.showInputDialog(null, "digite o titulo do h2:"));
                    break;
                case 3: // inserir paragrafo
                    site = new Paragrafo(site,
                            JOptionPane.showInputDialog(null, "digite o conteudo do primeiro paragrafo:"));
                    break;
                case 4: // Inserir Link
                    site = new Link(site, JOptionPane.showInputDialog(null, "digite a legenda do link:"),
                            JOptionPane.showInputDialog(null, "digite a url do link:"));
                    break;
                case 5: // Fechar Body
                    site = new FechaBodyMain(site);
                    bodyAberto = false;
                    break;
                case 6: // Fechar Div
                    if (divAberta > 0) {
                        site = new FechaDiv(site);
                        divAberta--;
                    } else {
                        JOptionPane.showInputDialog(null, "não existem divs abertas");
                    }
                    break;
                case 7: // "Inserir Footer"
                    if (divAberta > 0) {
                        for (int i = divAberta; i > 0; i--) {
                            divAberta--;
                            site = new FechaDiv(site);
                        }
                    }
                    if (bodyAberto == true) {
                        site = new FechaBodyMain(site);
                    }
                    site = new Footer(site, JOptionPane.showInputDialog(null, "Insira o conteúdo do rodapé:"));
                    site = new FechaSite(site);
                    site.build();
                    break;
                default : // "Fecha site"
                    if (divAberta > 0) {
                        for (int i = divAberta; i > 0; i--) {
                            divAberta--;
                            site = new FechaDiv(site);
                        }
                    }
                    if (bodyAberto == true) {
                        site = new FechaBodyMain(site);
                    }
                    site = new FechaSite(site);
                    site.build();
                    break;

            }

        }

    }
}
