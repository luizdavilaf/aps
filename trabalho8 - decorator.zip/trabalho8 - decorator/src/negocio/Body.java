package negocio;

public class Body extends HtmlDecorator {

    public Body(Html site) {
        super();
        super.componente = site;
    }

    

    @Override
    public String getCorpo() {        
        return super.componente.getCorpo() + "\n    <body class='body p-3 my-3 bg-dark text-white-50 text-left'>";
    }

   
    
}
