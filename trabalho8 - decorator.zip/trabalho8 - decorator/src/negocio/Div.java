package negocio;

public class Div extends HtmlDecorator {

    private String classe;

    public Div(Html site, String classe) {
        super();
        super.componente = site;
        this.classe = classe;
    }

    @Override
    public String getCorpo() {        
        return super.componente.getCorpo()+
        "\n     <div class='"+ this.classe + "'>";
    }

    

    

   
   
}
