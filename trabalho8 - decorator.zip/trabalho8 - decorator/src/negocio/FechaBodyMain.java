package negocio;

public class FechaBodyMain extends HtmlDecorator {

   

    public FechaBodyMain(Html site) {
        super();
        super.componente = site;
        
    }

    @Override
    public String getCorpo() {        
        return super.componente.getCorpo()+ 
        "\n</body>"+
        "\n</main>";
    }

    

    

   
   
}
