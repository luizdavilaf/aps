package negocio;

public class FechaDiv extends HtmlDecorator {

   

    public FechaDiv(Html site) {
        super();
        super.componente = site;
        
    }

    @Override
    public String getCorpo() {        
        return super.componente.getCorpo()+
        "\n</div>";
    }

    

    

   
   
}
