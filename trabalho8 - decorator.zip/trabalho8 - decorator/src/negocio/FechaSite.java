package negocio;

public class FechaSite extends HtmlDecorator {

   

    public FechaSite(Html site) {
        super();
        super.componente = site;
        
    }

    @Override
    public String getCorpo() {        
        return super.componente.getCorpo()+
        "\n</html>";
    }

    

    

   
   
}
