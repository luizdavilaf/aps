package negocio;

public class Footer extends HtmlDecorator{

    private String conteudo;

    public Footer(Html site, String conteudo) {
        super();
        super.componente = site;
        this.conteudo = conteudo;
    }
    @Override
    public String getCorpo() {       
        return super.componente.getCorpo()+
        "\n     <footer class='bg-secondary text-center text-white'>"  + this.conteudo + "</footer>";
    }

  
}
