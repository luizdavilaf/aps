package negocio;

public class H1 extends HtmlDecorator {

    private String titulo;

    public H1(String titulo) {
        super();        
        this.titulo = titulo;
    }

    public H1(Html site, String titulo) {
        super();
        super.componente = site;
        this.titulo = titulo;
    }

   

    @Override
    public String getCorpo() {        
        return super.componente.getCorpo() + "\n<h1>"+ this.titulo +"</h1>";    
    }


    public String insertCorpo() {        
        return "\n<h1>"+ this.titulo +"</h1>";
    }

  
    
}
