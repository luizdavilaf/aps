package negocio;

public class H2 extends HtmlDecorator{

    private String titulo;

    public H2(Html site, String titulo) {
        super();
        super.componente = site;
        this.titulo = titulo;
    }

    
   

    @Override
    public String getCorpo() {        
        return super.componente.getCorpo()+ "\n<h2>" + this.titulo + "</h2>";
    }

  

}
