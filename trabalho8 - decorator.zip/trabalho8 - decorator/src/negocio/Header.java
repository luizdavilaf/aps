package negocio;

public class Header extends HtmlDecorator {

    
    private H1 h1;

    public Header(Html site, H1 h1) {
        super();
        super.componente = site;
        
        this.h1 = h1;
    }

    

    @Override
    public String getCorpo() {        
        return super.componente.getCorpo() + 
        "\n     <header class='jumbotron bg-secondary text-center text-white'>" +  
        this.h1.insertCorpo()+ //dentro do header
        "\n</header>";
    


    }
   
    
}
