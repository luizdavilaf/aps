package negocio;

import java.awt.Desktop;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.file.Path;
import java.nio.file.Paths;

public abstract class Html {
    protected String corpo;

    public String getCorpo() {
        return corpo;
    }

    public void setCorpo(String corpo) {
        this.corpo = corpo;
    }

    public void build() throws IOException, URISyntaxException {
        FileWriter arquivo = new FileWriter("src/apresentacao/site.html");
        arquivo.write(this.getCorpo());
        arquivo.close();
        Path path = Paths.get("src/apresentacao/site.html");
        path = path.toAbsolutePath();
        File f = new File(path.toString());
        URI url = f.toURI();        
        Desktop.getDesktop().browse(url);
        

    }

}
