package negocio;

public abstract class HtmlDecorator extends Html{

    protected Html componente;

    

    @Override
    public String getCorpo() {        
        return componente.getCorpo();
    }

    
}
