package negocio;

public class Link extends HtmlDecorator {

    private String legenda;
    private String link;

    public Link(Html site, String legenda, String link) {
        super();
        super.componente = site;
        this.legenda = legenda;
        this.link = link;
    }

    

    @Override
    public String getCorpo() {       
        return super.componente.getCorpo()+
        "\n<a href='"+ this.link+"'>"+this.legenda+"</a>";
    }

    
}
