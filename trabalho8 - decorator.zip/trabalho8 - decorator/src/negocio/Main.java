package negocio;

public class Main extends HtmlDecorator {

    public Main(Html site) {
        super();
        super.componente = site;
    }

  

    @Override
    public String getCorpo() {
        // TODO Auto-generated method stub
        return super.componente.getCorpo() + "\n    <main class='container p-3 my-3 bg-dark text-white-50'>";
    }

    

}
