package negocio;

public class Paragrafo extends HtmlDecorator{

    private String conteudo;

    public Paragrafo(Html site, String conteudo) {
        super();
        super.componente = site;
        this.conteudo = conteudo;
    }

    

    @Override
    public String getCorpo() {        
        return super.componente.getCorpo()+ "\n<p>" + this.conteudo + "</p>" ;
    }


    

}
