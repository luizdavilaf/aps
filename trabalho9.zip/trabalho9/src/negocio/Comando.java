package negocio;

public enum Comando {
    SELECT,
    DELETE,
    UPDATE;
    
}
