package apresentacao;

import negocio.*;

public class App {

    public static void main(String[] args) throws Exception {
        

        

        Date q = new Date("20/02/2016");
        Date d = q.minusDays(99);
    }
}
